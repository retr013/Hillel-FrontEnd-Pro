var height = 6;
var radius = 3;

var volume = Math.PI * radius ** 2 * height ;

console.log('volume is ---> ', volume);